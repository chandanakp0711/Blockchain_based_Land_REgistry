import csv
import random

# Function to generate a random 12-digit Aadhar number
def generate_aadhar_number():
    return ''.join(random.choice('0123456789') for _ in range(12))

# Function to generate a random 6-digit OTP
def generate_otp():
    return ''.join(random.choice('0123456789') for _ in range(6))

# Create a list to hold the data
data = []

# Generate 10 random records
for _ in range(10):
    aadhar_number = generate_aadhar_number()
    otp = generate_otp()
    data.append([aadhar_number, otp])

# Write the data to a CSV file
with open('database.csv', 'w', newline='') as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(['Aadhar Number', 'OTP'])  # Write header
    csvwriter.writerows(data)

print("Data saved to data.csv")
