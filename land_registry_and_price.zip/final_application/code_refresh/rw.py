import numpy as np

a=1+2

