from bs4 import BeautifulSoup

# Read the HTML file
with open('index23.html', 'r') as file:
    html_content = file.read()

# Create a BeautifulSoup object
soup = BeautifulSoup(html_content, 'html.parser')

# Find all link elements with href attributes containing 'assets/'
link_elements = soup.find_all('link', href=lambda href: href and 'assets/' in href)

# Replace 'assets/' with '{{ url_for('static', filename='}}' in link elements
for link in link_elements:
    href = link.get('href')
    new_href = href.replace('assets/', "{{ url_for('static', filename='").replace("'", "") + "') }}"
    link['href'] = new_href

# Find all img elements with src attributes containing 'assets/'
img_elements = soup.find_all('img', src=lambda src: src and 'assets/' in src)

# Replace 'assets/' with '{{ url_for('static', filename='}}' in img elements
for img in img_elements:
    src = img.get('src')
    new_src = src.replace('assets/', "{{ url_for('static', filename='").replace("'", "") + "') }}"
    img['src'] = new_src

# Save the modified HTML back to the file
with open('index23.html', 'w') as file:
    file.write(str(soup))
