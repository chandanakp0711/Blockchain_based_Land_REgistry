
import joblib 
import numpy as np;
import pandas as pd;
import pymysql
pymysql.install_as_MySQLdb()
import MySQLdb
import matplotlib.pyplot  as plt;
from sklearn.model_selection  import train_test_split
from sklearn.linear_model  import LogisticRegression
from sklearn.metrics import accuracy_score,confusion_matrix
import pickle
gmail_list=[]
password_list=[]
gmail_list1=[]
password_list1=[]
import numpy as np;
import pandas as pd;
import matplotlib.pyplot  as plt;
from sklearn.model_selection  import train_test_split
from sklearn.linear_model  import LogisticRegression
from sklearn.metrics import accuracy_score,confusion_matrix
import pickle
from flask import Flask, request, render_template, redirect, url_for,send_file
import joblib
import csv
import os
import cv2
#knn_from_joblib = joblib.load('flight_price.pkl')
from yield_code import yield_fn
temp_aadhar = None
temp_aadhar1 = None
temp_otp = None
voted_details=[]
import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle

import refresh_code
import hashlib
import qrcode



# Load the trained model
model = joblib.load('random_forest_model_land_price.pkl')

# Create mappings for Location_Type and Legal_Status for user input
location_type_mapping = {'Urban': 0, 'Suburban': 1, 'Rural': 2}
legal_status_mapping = {'Clear': 0,'Disputed':1}


def check_hash_code_in_csv(hash_code):
    # Open the data.csv file and check if the hash code is present in the "hash_code" column
    with open('data.csv', 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            if row['hash_code'] == hash_code:
                return True
    return False
def update_csv_with_new_data(csv_filename, aadhar_number, otp):
    # Check if the CSV file already exists
    try:
        with open(csv_filename, mode='r') as file:
            # Read the existing data
            csv_reader = csv.reader(file)
            data = list(csv_reader)
    except FileNotFoundError:
        # If the file doesn't exist, create an empty list
        data = []

    # Add the new data to the list
    new_data = [aadhar_number, otp]
    data.append(new_data)

    # Write the updated data back to the CSV file
    with open(csv_filename, mode='w', newline='') as file:
        csv_writer = csv.writer(file)
        csv_writer.writerows(data)

features_list=['day', 'month', 'year', 'Duration_in_minutes', 'total_stops',
       'Air Asia', 'Air India', 'GoAir', 'IndiGo', 'Jet Airways',
       'Jet Airways Business', 'Multiple carriers',
       'Multiple carriers Premium economy', 'SpiceJet', 'Trujet', 'Vistara',
       'Vistara Premium economy', 'Banglore', 'Chennai', 'Delhi', 'Kolkata',
       'Mumbai', 'd_Banglore', 'd_Cochin', 'd_Delhi', 'd_Hyderabad',
       'd_Kolkata', 'd_New Delhi', 'Friday', 'Monday', 'Saturday', 'Sunday',
       'Thursday', 'Tuesday', 'Wednesday', 'Spring', 'Summer']


features_list1=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0,0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0,0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0,0,0]

# Function to store Aadhar number temporarily
def store_temp_aadhar(input_aadhar):
    global temp_aadhar
    temp_aadhar = input_aadhar


def store_temp_aadhar1(input_aadhar):
    global temp_aadhar1
    temp_aadhar1 = input_aadhar


# Function to store OTP temporarily
def store_temp_otp(input_otp):
    global temp_otp
    temp_otp = input_otp

#from recamandation_code import recondation_fn
#from recamandation_code_fh import recondation_fn_fh

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index23.html') 



@app.route('/nextpage')
def nextpage():

    return render_template('login41.html')



@app.route('/nextpage4')
def nextpage4():

    return render_template('land_owner_verification.html')


@app.route('/nextpage5')
def nextpage5():

    return render_template('land_price.html')


@app.route('/nextpage2')
def nextpage2():
    print("nothing")
    # Name of the file to modify
    file_name = 'refresh_code.py'

    # Import statement to add
    import_statement = 'import numpy as np\n'

    # Read the existing content of the file
    with open(file_name, 'r') as file:
        content = file.read()

    # Add the import statement at the beginning of the content
    modified_content = import_statement + content

    # Write the modified content back to the file
    with open(file_name, 'w') as file:
        file.write(modified_content)

    print(f"Added 'import numpy as np' to {file_name}")



    return render_template('Owner.html')



@app.route('/logedin1',methods=['POST'])
def logedin1():
    
    int_features3 = [str(x) for x in request.form.values()]
    print(int_features3)
    logu=int_features3[0]

    import csv

    def verify_aadhar_in_database(input_aadhar):
        # Initialize a flag to track whether the Aadhar number was found
        found = False

        # Read the CSV file containing Aadhar numbers and OTPs
        with open('database.csv', 'r') as csvfile:
            csvreader = csv.reader(csvfile)
            next(csvreader)  # Skip the header row

            # Iterate through the rows in the CSV file
            for row in csvreader:
                aadhar_number, otp = row
                if aadhar_number == input_aadhar:
                    found = True
                    store_temp_aadhar(input_aadhar)
                    store_temp_aadhar1(input_aadhar)

                    print(f"Aadhar number {input_aadhar} found with OTP: {otp}")
                    t=1
                    return t
                    break

        if not found:
          t=0
          return t

          print(f"Aadhar number {input_aadhar} not found in the database")

    p=verify_aadhar_in_database(logu)
    if p==1:
           return render_template('otp_verification.html') 
    else:
           return render_template('land_owner_verification.html') 
   # if int_features2[0]==12345 and int_features2[1]==12345:

@app.route('/logedin7',methods=['POST'])
def logedin7():
    
    int_features3 = [str(x) for x in request.form.values()]
    print(int_features3)
    logu=int_features3[0]

    import csv

    def verify_otp_in_database(input_otp):
        # Initialize a flag to track whether the Aadhar number was found
        found = False

        # Read the CSV file containing Aadhar numbers and OTPs
        with open('database.csv', 'r') as csvfile:
            csvreader = csv.reader(csvfile)
            next(csvreader)  # Skip the header row

            # Iterate through the rows in the CSV file
            for row in csvreader:
                aadhar_number, otp = row
                if otp == input_otp:
                    store_temp_otp(input_otp)
                    found = True
                    #print(f"Aadhar number {input_aadhar} found with OTP: {otp}")
                    t=1
                    return t
                    break

        if not found:
          t=0
          return t

          #print(f"Aadhar number {input_aadhar} not found in the database")

    verify_otp_in_database(logu)



    def verify_aadhar_with_otp(input_aadhar, input_otp):
        global temp_aadhar, temp_otp

        if temp_aadhar is not None and temp_otp is not None:
            # Read the CSV file containing Aadhar numbers and OTPs
            with open('database.csv', 'r') as csvfile:
                csvreader = csv.reader(csvfile)
                next(csvreader)  # Skip the header row

                # Iterate through the rows in the CSV file
                for row in csvreader:
                    aadhar_number, otp = row
                    if aadhar_number == temp_aadhar and otp == temp_otp:
                        print("Aadhar number and OTP match successfully!")
                        # Clear temporary variables
                        temp_aadhar = None
                        temp_otp = None
                        return 1  # Match found
                else:
                    print("Aadhar number and OTP do not match any records.")
                    temp_aadhar = None
                    temp_otp = None
                    return 0  # No match found
        else:
            print("Aadhar number and OTP verification failed. Please provide both Aadhar and OTP first.")
            return 0  # Verification failed


    p2=verify_aadhar_with_otp(temp_aadhar,temp_otp)


    if p2==1:





           return render_template('download_qrcode.html') 
    else:
           return render_template('otp_verification.html') 
   # if int_features2[0]==12345 and int_features2[1]==12345:


@app.route('/download')
def download():

    global temp_aadhar1


    qr_code_name=str(temp_aadhar1)+".png"
    temp_aadhar1= None
    file_path = qr_code_name
    return send_file(file_path, as_attachment=True)


@app.route('/logedin3',methods=['POST'])
def logedin3():
    
    int_features3 = [str(x) for x in request.form.values()]
    print(int_features3)
    logu=int_features3[0]

    return render_template('otp_verification.html') 

   # if int_features2[0]==12345 and int_features2[1]==12345:

@app.route('/predict239', methods=['POST'])
def predict239():
    # Retrieve input values from the form
    user_input = {
        'Location_Type': location_type_mapping[request.form['Location_Type']],
        'Proximity_to_City_km': float(request.form['Proximity_to_City_km']),
        'School_Distance_km': float(request.form['School_Distance_km']),
        'College_Distance_km': float(request.form['College_Distance_km']),
        'Land_Area_sqft': float(request.form['Land_Area_sqft']),
        'Public_Transport_Access': int(request.form['Public_Transport_Access']),
        'Road_Infrastructure': int(request.form['Road_Infrastructure']),
        'Legal_Status': legal_status_mapping[request.form['Legal_Status']],
        'Crime_Rate': float(request.form['Crime_Rate']),
        'Average_Income_Level': float(request.form['Average_Income_Level']),
        'Employment_Hub_Distance_km': float(request.form['Employment_Hub_Distance_km']),
        'Scenic_Value': int(request.form['Scenic_Value']),
        'Future_Development': int(request.form['Future_Development'])
    }

    # Convert user input into a DataFrame
    user_df = pd.DataFrame([user_input])

    # Make a prediction
    prediction = model.predict(user_df)
    predicted_price_per_sqft = prediction[0]

    # Render result
    return render_template('land_price.html', prediction_text=f"Predicted Price per Sqft: ₹{predicted_price_per_sqft:.2f}")

@app.route('/logedin',methods=['POST'])
def logedin():
    
    int_features3 = [str(x) for x in request.form.values()]
    print(int_features3)
    logu=int_features3[0]
    passw=int_features3[1]
   # if int_features2[0]==12345 and int_features2[1]==12345:

    import MySQLdb


# Open database connection
    db = MySQLdb.connect("localhost","root","","ddbb" )

# prepare a cursor object using cursor() method
    cursor = db.cursor()
    cursor.execute("SELECT user FROM user_register")
    result1=cursor.fetchall()
              #print(result1)
              #print(gmail1)
    for row1 in result1:
                      print(row1)
                      print(row1[0])
                      gmail_list.append(str(row1[0]))
                      
                      #gmail_list.append(row1[0])
                      #value1=row1
                      
    print(gmail_list)
    

    cursor1= db.cursor()
    cursor1.execute("SELECT password FROM user_register")
    result2=cursor1.fetchall()
              #print(result1)
              #print(gmail1)
    for row2 in result2:
                      print(row2)
                      print(row2[0])
                      password_list.append(str(row2[0]))
                      
                      #gmail_list.append(row1[0])
                      #value1=row1
                      
    print(password_list)
    print(gmail_list.index(logu))
    print(password_list.index(passw))
    
    if gmail_list.index(logu)==password_list.index(passw):
        # Read the CSV file
            # Read the CSV file
            df32 = pd.read_csv('voting_data.csv')

            # Count the occurrences of each class in the "voted" column
            vote_counts = df32['voted'].value_counts()

            # Determine the party with the most votes
            winner = vote_counts.idxmax()

            # Create a bar graph
            plt.figure(figsize=(8, 6))
            vote_counts.plot(kind='bar')
            plt.title('Vote Counts')
            plt.xlabel('Party')
            plt.ylabel('Count')
            plt.xticks(rotation=45)

            # Save the graph as an HTML file
            plt.savefig('static/vote_count.png')

            # Render an HTML template to display the graph and announce the winner
            return render_template('land_details.html', winner=winner)    
        #return render_template('vote_count.html')
    else:
        return jsonify({'result':'use proper  gmail and password'})
                  
                                               



                          
                     # print(value1[0:])
    
    
    
    

              
              # int_features3[0]==12345 and int_features3[1]==12345:
               #                      return render_template('index.html')
        
@app.route('/register',methods=['POST'])
def register():
    

    int_features2 = [str(x) for x in request.form.values()]
    #print(int_features2)
    #print(int_features2[0])
    #print(int_features2[1])
    r1=int_features2[0]
    print(r1)
    
    r2=int_features2[1]
    print(r2)
    logu1=int_features2[0]
    passw1=int_features2[1]
        
    

    

   # if int_features2[0]==12345 and int_features2[1]==12345:

    import MySQLdb


# Open database connection
    db = MySQLdb.connect("localhost","root",'',"ddbb" )

# prepare a cursor object using cursor() method
    cursor = db.cursor()
    cursor.execute("SELECT user FROM user_register")
    result1=cursor.fetchall()
              #print(result1)
              #print(gmail1)
    for row1 in result1:
                      print(row1)
                      print(row1[0])
                      gmail_list1.append(str(row1[0]))
                      
                      #gmail_list.append(row1[0])
                      #value1=row1
                      
    print(gmail_list1)
    if logu1 in gmail_list1:
                      return jsonify({'result':'this gmail is already in use '})  
    else:

                  #return jsonify({'result':'this  gmail is not registered'})
              

# Prepare SQL query to INSERT a record into the database.
                  sql = "INSERT INTO user_register(user,password) VALUES (%s,%s)"
                  val = (r1, r2)
   
                  try:
   # Execute the SQL command
                                       cursor.execute(sql,val)
   # Commit your changes in the database
                                       db.commit()
                  except:
   # Rollback in case there is any error
                                       db.rollback()

# disconnect from server
                  db.close()
                 # return jsonify({'result':'succesfully registered'})
                  return render_template('login.html')

                      


    
   






@app.route('/crop')
def crop():
     return render_template('index23.html')



@app.route('/crop/predict1',methods=['POST'])




def predict1():
    '''
    For rendering results on HTML GUI
    '''
    int_features1 = [str(x) for x in request.form.values()]

    # Get all form values and convert them to strings
    district = request.form.get('Brand')
    taluk = request.form.get('ProductID')
    hobli = request.form.get('ManufacturedDate')
    village = request.form.get('BatchNumber')
    survey_number = request.form.get('Price')
    surnoc = request.form.get('ProductType')
    hissa_number = request.form.get('BatchNumber3')
    period_year = request.form.get('Price3')
    owner_details = request.form.get('ProductType3')

    # Combine all details into a single string
    product_details = f"District: {district}, Taluk: {taluk}, Hobli: {hobli}, Village: {village}, Survey Number: {survey_number}, Surnoc: {surnoc}, Hissa Number: {hissa_number}, Period Year: {period_year}, Owner Details: {owner_details}"

    # Generate a hash code using SHA-256
    hash_code = hashlib.sha256(product_details.encode()).hexdigest()


    if not os.path.exists('data.csv'):
        # Create an empty DataFrame with the desired columns
        columns = ['District', 'Taluk', 'Hobli', 'Village', 'Survey Number', 'Surnoc', 'Hissa Number', 'Period Year', 'Owner Details', 'hash_code']
        df = pd.DataFrame(columns=columns)

        # Save the empty DataFrame to 'data.csv' with headers
        df.to_csv('data.csv', index=False)
    # Check if the product with the same hash code is already present in the CSV file
    # Check if the product with the same hash code is already present in the CSV file
    # Check if the product with the same hash code is already present in the CSV file
   # with open('data.csv', mode='r') as file:
     #   csv_reader = csv.DictReader(file)
    #    for row in csv_reader:
        #    if row['hash_code'] == hash_code:
                

    df = pd.read_csv('data.csv')

    # Check if the hash code is in the 'hash_code' column
    if hash_code in df['hash_code'].values:
        print("Product is already added to the database")
        return render_template('land_details.html', alert_text="Product is already added to the database")
    #else:
       # print("Product is not in the database")


    # If the product is not present, add it to the CSV file
    with open('data.csv', mode='a', newline='') as file:
        fieldnames = ['District', 'Taluk', 'Hobli', 'Village', 'Survey Number', 'Surnoc', 'Hissa Number', 'Period Year', 'Owner Details', 'hash_Code']
        writer = csv.DictWriter(file, fieldnames=fieldnames)

        # Write a new row with the product details and hash code
        writer.writerow({
            'District': district,
            'Taluk': taluk,
            'Hobli': hobli,
            'Village': village,
            'Survey Number': survey_number,
            'Surnoc': surnoc,
            'Hissa Number': hissa_number,
            'Period Year': period_year,
            'Owner Details': owner_details,
            'hash_Code': hash_code
        })

    # Generate a QR code and save it as you were doing before
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(hash_code)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    img.save(str(owner_details) + ".png")

    otp1="1234"



    update_csv_with_new_data("database.csv",owner_details, otp1)

    return render_template('land_details.html', alert_text="Product added successfully")

   # return render_template('otp_verification.html')

@app.route('/crop1/predict23',methods=['POST'])
def predict23():
    '''
    For rendering results on HTML GUI
    '''

    # Initialize the webcam
    cap = cv2.VideoCapture(1)  # 0 for the default camera

    while True:
        # Capture a frame from the webcam
        ret, frame = cap.read()

        # Detect and decode the QR code in the frame
        detector = cv2.QRCodeDetector()
        decoded_info, points, straight_qrcode = detector.detectAndDecode(frame)

        # If a QR code is detected, check the CSV file for the hash code
        if decoded_info:

            
            print("Decoded QR Code Data:")
            print(decoded_info)

            # Read data from the CSV file
            with open('data.csv', 'r') as csv_file:
                csv_reader = csv.DictReader(csv_file)
                for row in csv_reader:
                    if row['hash_code'] == decoded_info:
                        # Return product details from the CSV file
                        #print("Buyer data is safe")  
                        #break
                        return render_template('verification.html', alert_text1="Data is Verified-- Details", product_details=row)

            # If the hash code is not found in the CSV file
            return render_template('verification.html', alert_text1="No Records Availlable")

        # Display the frame with detected QR code (optional)
        cv2.imshow("QR Code Scanner", frame)

        # Break the loop if the 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close OpenCV windows 
    print("Buyer data is safe")
    cap.release()
    cv2.destroyAllWindows()

    #print("Buyer data is safe") 







@app.route('/crop2')
def crop2():
    return render_template('crop2.html')



@app.route('/crop2/predict2',methods=['POST'])
def predict2():
    '''
    For rendering results on HTML GUI
    '''
    int_features12 = [str(x) for x in request.form.values()]


    output11 = recondation_fn_fh(int_features12)
   # resultcrop = {value:key for key, value in croplist.items()}
    print(output11)


 
    

    

    return render_template('crop2.html', prediction1_text='Health condition Level is    {}'.format(output11[0]))


@app.route('/crop2/predict2/vote1',methods=['POST'])
def vote1():
    '''
    For rendering results on HTML GUI
    '''
    int_features12 = [str(x) for x in request.form.values()]


    #output11 = recondation_fn_fh(int_features12)
   # resultcrop = {value:key for key, value in croplist.items()}
    print(int_features12)

    output11=int_features12[0]


    voted_details.append(str(int_features12[0]))

    df1= pd.read_csv('voting_data.csv')


    print(voted_details[0:3])
    df1 = df1.append({'adhar_number': voted_details[0], 'otp':voted_details[1], 'voted': voted_details[2]}, ignore_index=True)
            
            # Save the updated DataFrame back to the CSV file
    df1.to_csv('voting_data.csv', index=False)


    voted_details.clear()




 
    

    

    return render_template('index4.html')



if __name__ == "__main__":
    app.run(debug=True)
